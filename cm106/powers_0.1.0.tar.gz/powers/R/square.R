#' @title Square the input
#' @param x Vector of numerics
#' @return The vextor x, squared.
#' @export namespace
square <- function(x) pow(x, 2)
